#pragma once

#include "fastpin_esp8266.h"
#include "clockless_esp8266.h"
#include "clockless_block_esp8266.h"
